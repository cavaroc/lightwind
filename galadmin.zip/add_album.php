<?php
include('includes/init.php');
include('includes/header.php');

if(isset($_POST['album_submit'])) {
	
	$newAlbum = $_POST['new_album'];
	
	$albumAdd = "INSERT INTO albums (albumname) VALUES (:album_name)";
	$albumQuery = $db->prepare($albumAdd);
	$albumQuery->execute(array(':album_name' => $newAlbum));
	
	echo 'Album added successfully!';
}
?>

<h1>Create New Album</h1>

<form action="" method="post">

<input name="new_album" placeholder="New Album Name">
<input name="album_submit" type="submit" value="Add">

</form>

<?php include ('includes/footer.php'); ?>