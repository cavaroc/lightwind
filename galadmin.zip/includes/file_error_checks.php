<?php
	$errors = array();
	$allowed_ext = 'jpg';
	$file_name = $_FILES['upload']['name'];
	// $file_ext = end(explode('.',$file_name));
	// $file_ext = strrpos($_FILES['upload']['name'], '.');
	// echo $file_ext;
	
	$file_size = $_FILES['upload']['size'];
	$file_tmp = $_FILES['upload']['tmp_name'];
	// if ($file_ext != $allowed_ext) {
	// if (exif_imagetype($file_name) != IMAGETYPE_JPEG) {
		/*
	if (!in_array(exif_imagetype($file_name), $file_name)) {
		$errors[] = 'Extension not allowed';
	} 
	if ($file_size > 5242880) {
		$errors[] = 'Too big.';
	} */
?>