<?php
			$galleryFlag = 1;
			$galleryName = $galleryNew;
			
			if (!empty($_POST['galleryslug'])) {
				$gallerySEOName = $_POST['galleryslug'];
			} else {
				$gallerySEOName = strtolower(preg_replace('/\s+/','-',trim($galleryName)));
			}
			// $galleryDir =	galleryTools($galleryNew, $galleryFlag);
			mkdir("../public_html/photos/".$gallerySEOName, 0755);
			mkdir("../public_html/photos/".$gallerySEOName."/thumbnails/", 0755);

			$addGalleryInfo = $db->prepare("
				INSERT INTO galleries (galleryname,galleryurlname)
				VALUES (:galleryname,:galleryurlname)
			");
			$addGalleryInfo->execute(array(
				'galleryname' =>	$galleryName,
				'galleryurlname' =>	$gallerySEOName
			));
			$newGalId = $db->lastInsertId();
?>