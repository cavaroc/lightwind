<?php
$dbpass = "your db password";
try {
  $db = new PDO('mysql:host=localhost;dbname=[your db name]', '[db username]', $dbpass,
  array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (PDOException $e) {
  echo 'Error connecting to the database...';
}
define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT']);
?>