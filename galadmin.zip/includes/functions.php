<?php
/*
// -- Convert EXIF date taken to readable format
function convertExifDate($exifString, $dateFormat) {
	$exifPieces = explode(" ", $exifString);
	return date($dateFormat, strtotime(str_replace(":","-",$exifPieces[0])." ".$exifPieces[1]));
}
*/

// -- Make a new directory for new galleries or use existing dir otherwise
// --   and return web-friendly path
function galleryTools($galleryPass, $galFlag) {
	if (isset($galleryPass)) {
		$gallerydir = strtolower($galleryPass);
		$gallerydir = preg_replace('/[\s]+/', '-', $gallerydir);
	} else {
		echo 'Problem copying/creating gallery.';
	}
	if ($galFlag == 0) {
		return $gallerydir;
	} else {
		mkdir("../public_html/photos/".$gallerydir, 0777);
		mkdir("../public_html/photos/".$gallerydir."/thumbnails/", 0777);
		return $gallerydir;
	}
}

// -- Convert filename to SEO friendly name
function convertFilename($exiffilename, $galleryDir, $z) {
	$tmpimgname = end(explode('.',$exiffilename));
	// $tmpdir = end(explode('/',$galleryDir));
	$imgname = $galleryDir.$z.'.'.$tmpimgname;
	// echo $imgname, '<br />';
	return $imgname;
}

?>