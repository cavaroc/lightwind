<?php
			$addPhoto = $db->prepare("
				INSERT INTO photos (gallery, gallery_id, imgname, exifdatetaken, exifdesc, exiftitle, exifkeywords, exifcamera, exiffilename, filepath, pricing, ontandem, subgallery_pic, favorite, homeslide)
				VALUES (:gallery, :gallery_id, :imgname, :exifdatetaken, :exifdesc, :exiftitle, :exifkeywords, :exifcamera, :exiffilename, :filepath, :pricing, :ontandem, :subgallery_pic, :favorite, :homeslide)
			");
			
			$photoAddArray = array(
				':gallery' => 		$galleryName,
				':gallery_id' =>	$newGalId,
				':imgname' => 		$imgname,
				':exifdatetaken' => $datetaken,
				':exifdesc' =>		$exifdesc,
				':exiftitle' => 	$exiftitle,
				':exifkeywords' => 	$exifkeywords,
				':exifcamera' => 	$exifcamera,
				':exiffilename' => 	$exiffilename,
				':filepath' => 		$gallerySEOName,
				':pricing' =>		'standard',
				':ontandem' =>		0,
				':subgallery_pic' =>0,
				':favorite' =>		0,
				':homeslide' =>		0
			);
	
			$addPhoto->execute($photoAddArray);		
?>