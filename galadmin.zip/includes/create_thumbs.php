<?php
			$img_w = $size[0];
			$img_h = $size[1];
			
            // Get multiplier to create new thumbnail dimensions and maintain aspect ratio
			$new_size = ($img_w + $img_h) / ($img_w * ($img_h / 200));
            $tiny_size = ($img_w + $img_h) / ($img_w * ($img_h / 10));
                        
            // Create dimensions for new thumbnails
			$new_w = $img_w * $new_size;
			$new_h = $img_h * $new_size;

            // Create dimensions for new tiny thumbs for lazy loading
            $tiny_w = $img_w * $tiny_size;
            $tiny_h = $img_h * $tiny_size;
			
            // Create new thumbnails and tiny thumbnails
			$new_image = imagecreatetruecolor($new_w, $new_h);
            $tiny_image = imagecreatetruecolor($tiny_w, $tiny_h);

			$orig_img = imagecreatefromjpeg($tmp_name);
			
			imagecopyresampled($new_image, $orig_img, 0, 0, 0, 0, $new_w, $new_h, $img_w, $img_h);
            imagecopyresampled($tiny_image, $orig_img, 0, 0, 0, 0, $tiny_w, $tiny_h, $img_w, $img_h);

			imagejpeg($new_image, '../public_html/photos/'.$gallerySEOName.'/thumbnails/'.$imgname);
            imagejpeg($tiny_image, '../public_html/photos/'.$gallerySEOName.'/tiny/'.$imgname);
			
			move_uploaded_file($tmp_name, "../public_html/photos/".$gallerySEOName."/".$imgname);
?>