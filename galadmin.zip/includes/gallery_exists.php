<?php
			$galleryGet = $db->prepare("SELECT gallery_id, galleryurlname, galleryname FROM galleries WHERE gallery_id=:gallery_id");
			$galleryGet->execute(array(':gallery_id' => $galleryChoice));

			// -- Assign gallery info from galleries table to be used in assigning gallery_id to photos table
			while ($galRow = $galleryGet->fetch()) {
				$galleryName = $galRow['galleryname'];
				$gallerySEOName = $galRow['galleryurlname'];
				$newGalId = $galRow['gallery_id'];
			}
			
			$galleryFlag = 	0;
?>