<!DOCTYPE html>
<html>
<head>
<meta name="robots" content="noindex,follow">
<title><?php echo $page_title; ?></title>
<meta name="description" content="<?php echo $theDescription; ?>">
<meta charset="utf-8">
<meta name="author" content="Mike Cavaroc">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="HandheldFriendly" content="true">
<link rel="Shortcut Icon" type="image/x-icon" href="https://www.freeroamingphotography.com/favicon.ico">
<link rel="stylesheet" href="/includes/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="style.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="js/scripts.js"></script>

</head>

<body>
<nav>
<ul>
<li><a href="https://www.freeroamingphotography.com" target="_blank">Main Site</a></li>
<li><a href="upload.php">Upload Photos</a></li>
<li><a href="gallery_manage.php">Gallery Management</a></li>
<li><a href="add_album.php">Add Album</a></li>
</ul>
</nav>
<section id="content">