<?php
$getPhotoId = $db->prepare("SELECT * FROM photos");
$getPhotoId->execute();
$ids = $getPhotoId->fetchAll(PDO::FETCH_OBJ);
$lastId = ($getPhotoId->rowCount() + 1);
?>