<?php
			$tmp_name = 		$files['tmp_name'][$x];
			$exifdata =			exif_read_data($tmp_name);
			$datetaken = 		$exifdata['DateTimeOriginal'];
			$exifdesc = 		$exifdata['ImageDescription'];
			$exifcamera = 		$exifdata['Model'];
			$exiffilename = 	$files['name'][$x];
		
			$size = 			getimagesize($tmp_name, $infos);
			$iptc = 			iptcparse($infos['APP13']);
			$exiftitle = 		$iptc["2#105"][0];
			// $exifdatetaken = 	convertExifDate($datetaken, "Y, F j");

			$exifkeywords =		null;
			$keywordcount =	 	count($iptc["2#025"]);
			for ($y=0; $y < $keywordcount; $y++) {
				$exifkeywords .= $iptc["2#025"][$y];
				if ($y < ($keywordcount-1)) {
					$exifkeywords .= ", ";
				}
			}
		
			// -- Convert filename to SEO-friendly name and move to permanent directory
			$imgname = 			convertFilename($exiffilename, $gallerySEOName, ($lastId++));
?>