<?php
$adminIncDir = $_SERVER['DOCUMENT_ROOT'].'/includes/';
include('includes/init.php');
include('includes/functions.php');

$newFlag = 0;

// -- Get the number of IDs to create unique number in filename
include('includes/unique_id_query.php');

// -- Check if anything was uploaded
if (isset($_FILES['upload'])) {
	
	// -- Check validity of uploaded files
	include('includes/file_error_checks.php');

	if (empty($errors)) {
	
		// -- Check if a new gallery or existing gallery is to be used
		$galleryChoice = 	$_POST['galleryChoice'];
		$galleryNew = 		$_POST['galleryNew'];
		
		// -- ADD INTO FIRST CONDITION URL FRIENDLY GALLERY NAME
		if ($galleryChoice != "Select Gallery") {
			include('includes/gallery_exists.php');
		} else {
			include('includes/new_gallery.php');
		}

		// -- Assign $files the uploaded files
		$files = $_FILES['upload'];

		// -- Get information from the files and assign them to variables
		for ($x=0; $x < count($files['name']); $x++) {
			include('includes/process_files.php');
			include('includes/create_thumbs.php');
			include('includes/add_to_db.php');
		}

		$newFlag = 1;
		
	} else {
		foreach ($errors as $error) {
			echo $error, $file_ext, '<br>';
		}
	}
}

$getGalleries = $db->prepare("SELECT gallery_id,galleryname FROM galleries ORDER BY galleryname");
$getGalleries->execute();
$getGalleries = $getGalleries->fetchAll(PDO::FETCH_OBJ);

include('includes/header.php');
?>

<h1>Image Upload</h1>

<?php if ($newFlag == 1) {
	echo '<p>Everything was uploaded successfully!</p>';
} ?>

<div id="uploadForm">
<form action="" method="post" enctype="multipart/form-data">
	<input type="file" name="upload[]" multiple>
	<select name="galleryChoice">
		<option value="Select Gallery">Select a Gallery</option>
		<?php foreach ($getGalleries as $galleryInfo): ?>
		<option value="<?php echo $galleryInfo->gallery_id; ?>"><?php echo $galleryInfo->galleryname; ?></option>
		<?php endforeach; ?>
	</select>
	<p>Or enter a new gallery<br>
	<input type="text" name="galleryNew" placeholder="New Gallery"></p>
	<p>SEO-friendly name (no spaces, lowercase, etc)<br>
	<input type="text" name="galleryslug" placeholder="SEO-Friendly Name"></p>
	<input type="submit" value="Upload">
</form>
</div>

<?php include('includes/footer.php'); ?>