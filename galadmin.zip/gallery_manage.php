<?php
include('includes/init.php');
include('includes/header.php');
?>

<h1>Gallery Management</h1>

<?php
if(isset($_GET['id'])) {
	$galId = htmlspecialchars($_GET['id']);

	if(isset($_POST['edit_gallery'])) {
		$numIds = count($_POST['photo_id']);
		for ($x=0; $x<$numIds; $x++) {
			$postId = $_POST['photo_id'][$x];
			$postTitle = $_POST['photo_title'][$x];
			$postDesc = $_POST['photo_desc'][$x];
			$postKeywords = $_POST['photo_keywords'][$x];
			$postTandemId = $_POST['tandem_id'][$x];
			if (!empty($postTandemId)) {
				$onTandem=1;
			} else {
				$onTandem=0;
			}
			$postFav = $_POST['favorite'][$x];
			$postSlide = $_POST['homeslide'][$x];
			$postPricing = $_POST['pricing'][$x];
			$postFeatured = $_POST['featured_pic'][$x];
			
			if ($_POST['subfeatured_pic'][$x]==1) {
				$postSubFeatured = 1;
			} else {
				$postSubFeatured = 0;
			}				
			if (!empty($_POST['newsubgallery'][$x])) {
				$subGallery = $_POST['newsubgallery'][$x];
				$subGalSlug = strtolower(preg_replace('/\s+/','-',trim($subGallery)));
			} else {
				$subGallery = $_POST['subgallery'][$x];
				$subGalSlug = strtolower(preg_replace('/\s+/','-',trim($subGallery)));
			}
			$newGalleryId = $_POST['changeGallery'][$x];
			
			$updateQuery = 'UPDATE photos SET 
				exiftitle=:exiftitle, exifdesc=:exifdesc, exifkeywords=:exifkeywords, tandemid=:tandemid, favorite=:favorite, homeslide=:homeslide, ontandem=:ontandem, 
				pricing=:pricing, subgallery=:subgallery, subgallery_pic=:subgallery_pic, gallery_id=:gallery_id, subgalleryslug=:subgalleryslug
				WHERE id=:id';
			$preparedStatement = $db->prepare($updateQuery);
			$preparedStatement->execute(array(
			':exiftitle' => $postTitle, 
			':exifdesc' => $postDesc, 
			':exifkeywords' => $postKeywords,
			':tandemid' => $postTandemId,
			':favorite' => $postFav,
			':homeslide' => $postSlide,
			':ontandem' => $onTandem,
			':pricing' => $postPricing,
			':subgallery' => $subGallery,
			':subgallery_pic' => $postSubFeatured,
			':gallery_id' => $newGalleryId,
			':subgalleryslug' => $subGalSlug,
			':id' => $postId
			));
			
			if (!empty($postFeatured)) {
				$gallerySlug = $_POST['slug'];
				$lat = $_POST['lat'];
				$lng = $_POST['lng'];
				$galleryDesc = $_POST['gallerydesc'];
				$parentGallery = $_POST['parent_album'];

				$updateGalQuery = 'UPDATE galleries SET
							galleryurlname=:galleryslug, gallerydesc=:gallery_desc, album_id=:album_id, featured_pic=:featured_pic, lat=:lat, lng=:lng
							WHERE gallery_id=:gallery_id';
				$secondPrepared = $db->prepare($updateGalQuery);
				$secondPrepared->execute(array(
					':galleryslug' => $gallerySlug,
					':gallery_desc' => $galleryDesc,
					':album_id' => $parentGallery,
					':featured_pic' => $postFeatured,
					':lat' => $lat,
					':lng' => $lng,
					':gallery_id' => $galId
				));
			}			
		}
	}

	echo '<form action="" method="post">';
	
	$getAllGalleries = $db->prepare("SELECT gallery_id,galleryname FROM galleries WHERE gallery_id != :gallery_id ORDER BY galleryname");
	$getAllGalleries->execute(array(':gallery_id' => $galId));
	$allGalleries = $getAllGalleries->fetchAll();
	
	$getGalleryInfo = $db->prepare("SELECT galleryname,galleryurlname,gallerydesc,album_id,featured_pic,lat,lng FROM galleries WHERE gallery_id=:gallery_id");
	$getGalleryInfo->execute(array(':gallery_id' => $galId));
	while ($row = $getGalleryInfo->fetch()) {
		$galleryName 	= $row['galleryname'];
		$gallerySlug	= $row['galleryurlname'];
		$galleryDesc 	= $row['gallerydesc'];
		$galAlbumId 	= $row['album_id'];
		$galleryCover 	= $row['featured_pic'];
		$galLat			= $row['lat'];
		$galLng			= $row['lng'];
	}
	
	echo '<h2>'.$galleryName.'</h2>';
	echo '<p>Gallery slug:<br><input type="text" name="slug" value="'.$gallerySlug.'"></p>';
	echo '<p><textarea name="gallerydesc" class="galleryDesc">'.$galleryDesc.'</textarea></p>';

	echo '<div class="clearFix"><div style="float: left; width: 300px;">Parent Album<br>';
	echo '<select name="parent_album">';
	$getAlbumInfo = $db->prepare("SELECT album_id,albumname FROM albums");
	$getAlbumInfo->execute();
	while ($row = $getAlbumInfo->fetch()) {
		if ($galAlbumId != $row['album_id']) {
			echo '<option value="'.$row['album_id'].'">'.$row['albumname'].'</option>';
		} else {
			echo '<option value="'.$row['album_id'].'" selected>'.$row['albumname'].'</option>';
		}
	}
	echo '</select></div>';
	
	echo '<div style="float: left; width: 300px;">Latitude<br><input type="text" name="lat" value="'.$galLat.'"></div>';
	echo '<div style="float: left; width: 300px;">Longitude<br><input type="text" name="lng" value="'.$galLng.'"></div></div>';
	
	$getSubGals = $db->prepare("SELECT subgallery FROM photos WHERE gallery_id=:gallery_id GROUP BY subgallery");
	$getSubGals->execute(array(':gallery_id' => $galId));
	$subgalleries = $getSubGals->fetchAll();
	
	
	$perPage = 100;
		$searchCountQuery = $db->prepare("SELECT id FROM photos WHERE gallery_id=:gallery_id");
		$searchArray = array(':gallery_id' => $galId);
		$searchCountQuery->execute($searchArray);
		if ($searchCountQuery === false) {
			var_dump($searchCountQuery->errorInfo());
		}
		
		$searchCount = count($searchCountQuery->fetchAll());
		$rowCount = ceil($searchCount/$perPage);

		if(isset($_GET['page'])) {
			$pageGet = $_GET['page'];
		} else {
			$pageGet = "";
		}

		if($pageGet == "" || $pageGet == 1) {
			$page1 = 0;
		} else {
			$page1 = ($pageGet * $perPage) - $perPage;
		}
		
		$getPhotoInfo = $db->prepare("SELECT id,gallery,gallery_id,subgallery,subgallery_pic,imgname,filepath,exifdesc,exiftitle,exifkeywords,ontandem,tandemid,favorite,homeslide,pricing FROM photos 
		WHERE gallery_id=:gallery_id ORDER BY subgallery ASC, exifdatetaken DESC LIMIT :page_num,:per_page");
		$qArray = array(
			':gallery_id' => $galId,
			':page_num' =>	 $page1,
			':per_page' =>	 $perPage
			);
		$getPhotoInfo->execute($qArray);
		
	
/*	
	
	$getPhotoInfo = $db->prepare("
		SELECT id,gallery,gallery_id,subgallery,subgallery_pic,imgname,filepath,exifdesc,exiftitle,exifkeywords,ontandem,tandemid,favorite,pricing FROM photos 
		WHERE gallery_id=:gallery_id
		");
	$getPhotoInfo->execute(array(':gallery_id' => $galId));
	*/
	?>
	<br>
	<div class="gallerySubmit">
		<button type="submit" name="edit_gallery" value="Apply">Save All Changes</button>
	</div>
	<table>
	<tr>
	<th>ID<br>Image Thumb</th>
	<th>Image Name<br>Title<br>Description</th>
	<th>Keywords</th>
	<th>Tandem ID<br>Favorite<br>Cover Image</th>
	<!-- <th>Subgallery</th> -->
	<th>Pricing<br>Remove<br>Gallery Change</th>
	</tr>
	<?php
	while ($row = $getPhotoInfo->fetch()) {
		
		$photoId = $row['id'];
		$photoTitle = $row['exiftitle'];
		$photoPath = $row['filepath'];
		$photoName = $row['imgname'];
		$photoDesc = $row['exifdesc'];
		$photoTandemId = $row['tandemid'];
		$photoFav = $row['favorite'];
		$photoSlide = $row['homeslide'];
		$photoPricing = $row['pricing'];
		$photoSubGal = $row['subgallery'];
		$photoSubGalPic = $row['subgallery_pic'];
		
		echo '<tr>';
		echo '<td><p>'.$photoId.'<input type="hidden" id="photo_id" name="photo_id[]" value="'.$photoId.'"></p>';
		echo '<img title="'.$photoTitle.'" src="https://www.freeroamingphotography.com/photos/'.$photoPath.'/thumbnails/'.$photoName.'" width="125" alt="'.$photoTitle.'">';
		echo '<td><p>'.$photoName.'</p>';
			echo '<p><input id="photo-title" type="text" name="photo_title[]" value="'.$photoTitle.'"></p>';
			echo '<textarea id="photo-desc" name="photo_desc[]">'.$photoDesc.'</textarea></td>';
		echo '<td><textarea id="phoot-keywords" name="photo_keywords[]">'.$row['exifkeywords'].'</textarea><br>';
		echo '<p><input type="text" size="5" id="photo-tandemid" name="tandem_id[]" placeholder="Tandem ID" value="'.$photoTandemId.'"></p></td>';
		echo '<td>';
			echo '<p>Home Slide<br><select name="homeslide[]" id="photo-slide">';
			if ($row['homeslide']==0) {
				echo '<option value="0">No</option>';
				echo '<option value="1">Yes</option>';
			} else {
				echo '<option class="yesOption" value="1">Yes</option>';
				echo '<option value="0">No</option>';
			}
			echo '</select></p><p>Favorite<br><select name="favorite[]" id="photo-fav">';
			if ($row['favorite']==0) {
				echo '<option value="0">No</option>';
				echo '<option value="1">Yes</option>';
			} else {
				echo '<option class="yesOption" value="1">Yes</option>';
				echo '<option value="0">No</option>';
			}
			echo '</select></p><p>Cover Image<br>';
			if ($galleryCover != $photoName) {
				echo '<input type="radio" name="featured_pic[]" value="'.$photoName.'" id="photo-cover">';
			} else {
				echo '<input type="radio" name="featured_pic[]" value="'.$photoName.'" id="photo-cover" checked>';
			}
			echo '</select></p></td>';
			
		/*echo '<td><select name="subgallery[]">';
		if (!empty($photoSubGal)) {
			foreach ($subgalleries as $subgals) {
				if ($photoSubGal == $subgals['subgallery']) {
					echo '<option value="'.$subgals['subgallery'].'" selected>'.$subgals['subgallery'].'</option>';
				} else {
					echo '<option value="'.$subgals['subgallery'].'">'.$subgals['subgallery'].'</option>';
				}
			}
		} else {
			foreach ($subgalleries as $subgals) {
				echo '<option value="'.$subgals['subgallery'].'">'.$subgals['subgallery'].'</option>';
			}
		}
		echo '</select><p>Subgallery Cover Image<select name="subfeatured_pic[]">';
		if ($photoSubGalPic != 1) {
			echo '<option value="0" selected>No</option><option value="1">Yes</option>';
		} else {
			echo '<option value="1" selected>Yes</option><option value="0">No</option>';
		}
		echo '</select></p>';
		echo '<input type="text" name="newsubgallery[]" placeholder="New Subgallery"></td>';
		*/
		echo '<td><p><select name="pricing[]">';
		switch ($photoPricing) {
			case "standard":
				echo '<option value="standard" selected>Standard</option>';
				echo '<option value="panorama">Panorama</option>';
				echo '<option value="square">Square</option>';
				break;
			case "panorama":
				echo '<option value="standard">Standard</option>';
				echo '<option value="panorama" selected>Panorama</option>';
				echo '<option value="square">Square</option>';
				break;
			default:
				echo '<option value="standard">Standard</option>';
				echo '<option value="panorama">Panorama</option>';
				echo '<option value="square" selected>Square</option>';
				break;	
		}
		echo '</select></p>';
		echo '<p><a href="gallery_manage.php?remove='.$photoId.'&galid='.$galId.'">Remove</a></p><p>Change Galleries<br>';
		
		echo '<select name="changeGallery[]"><option value="'.$galId.'">'.$galleryName.'</option>';
		foreach ($allGalleries as $key) {
			echo '<option value="'.$key['gallery_id'].'">'.$key['galleryname'].'</option>';
		}
		echo '</select></p></td>';
		echo '</tr>';
	}
	?>
	</table>
	</form>
	<?php
	if ($rowCount > 1) { ?>
		<div class="pagination">
			<ul class="pagey">

			<?php
			
			for ($i=1;$i<=$rowCount;$i++) {
				if ($i == $pageGet) {
					echo '<li><a href="gallery_manage.php?id=',$galId,'&page=',$i,'" class="activeLink">',$i,'</a></li>';
				} else {
					echo '<li><a href="gallery_manage.php?id=',$galId,'&page=',$i,'">',$i,'</a></li>';
				}
			}
			?>

			</ul>
		</div>
		<?php } ?>

	<?php
} else if (isset($_GET['remove'])) {
	$removeId = $_GET['remove'];
	$galId = $_GET['galid'];
	$removePhoto = $db->prepare("DELETE FROM photos WHERE id=:photo_id");
	$removePhoto->execute(array(':photo_id' => $removeId));
	$newUrl = 'gallery_manage.php?id='.$galId;
	header("Location: ".$newUrl);
} else {
	echo '<form id="galSelect" action="" method="get">';
	echo '<select id="id" name="id" onchange="this.form.submit();">';
	echo '<option>Select a Gallery</option>';
	$getGalleries = $db->prepare("SELECT gallery_id,galleryname FROM galleries ORDER BY galleryname");
	$getGalleries->execute();
	while ($row = $getGalleries->fetch()) {
		echo '<option value="'.$row['gallery_id'].'">'.$row['galleryname'].'</option>';
	}
	echo '</select></form>';
}
?>